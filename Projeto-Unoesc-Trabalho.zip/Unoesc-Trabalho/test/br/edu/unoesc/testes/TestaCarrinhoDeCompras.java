package br.edu.unoesc.testes;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

import java.util.List;

import org.junit.Before;
import org.junit.Test;

import br.edu.unoesc.carrinho.Carrinho;
import br.edu.unoesc.carrinho.ItemCarrinho;
import br.edu.unoesc.produto.Bebida;
import br.edu.unoesc.produto.Comida;
import br.edu.unoesc.produto.Produto;
import br.edu.unoesc.produto.Vestuario;

/**
 * 
 * @author grando
 * 
 */
public class TestaCarrinhoDeCompras {

	private Produto cerveja;
	private Produto camiseta;

	private Produto pepsi;
	private Produto pizza;

	@Before
	public void before() {
		cerveja = new Bebida();
		cerveja.setNome("Skol");
		cerveja.setDescricao("Desce redondo");
		cerveja.setPreco(5.0);

		camiseta = new Vestuario();
		camiseta.setNome("Polo Red Bull");
		camiseta.setDescricao("Camisa de algod�o para o dia-a-dia");
		camiseta.setPreco(100.0);

		pepsi = new Bebida();
		pepsi.setNome("Pepsi");
		pepsi.setDescricao("Melhor que a Coca Cola");
		pepsi.setPreco(10.0);

		pizza = new Comida();
		pizza.setNome("Sadia - Sabor Portuguesa");
		pizza.setDescricao("Massa crocante e r�pida de assar");
		pizza.setPreco(15.0);
	}

	// 1
	@Test
	public void deveIncluirUmProdutoAoCarrinho() {
		ItemCarrinho item1 = new ItemCarrinho(camiseta, 1);
		Carrinho carrinho = new Carrinho();
		carrinho.adicionaAoCarrinho(item1);

		assertThat(carrinho.getItens().size(), is(1));
		assertThat(carrinho.getItens().get(0).getQuantidade(), is(1));
	}

	// 1
	@Test
	public void deveIncluirVariosProdutosEQuantidades() {
		ItemCarrinho item1 = new ItemCarrinho(cerveja, 1);
		ItemCarrinho item2 = new ItemCarrinho(camiseta, 2);
		ItemCarrinho item3 = new ItemCarrinho(pizza, 3);

		Carrinho carrinho = new Carrinho();
		carrinho.adicionaAoCarrinho(item1);
		carrinho.adicionaAoCarrinho(item2);
		carrinho.adicionaAoCarrinho(item3);

		assertThat(carrinho.getItens().size(), is(3));

		int quantidadeTotal = 0;
		for (ItemCarrinho item : carrinho.getItens()) {
			quantidadeTotal += item.getQuantidade();
		}

		assertThat(quantidadeTotal, is(6));
	}

	// 2
	@Test
	public void deveRetornarValorUnitarioDoProduto() {
		assertThat(camiseta.getPreco(), is(100.0));
	}

	// 3
	@Test
	public void deveOrdenarPeloPrecoDescendente() {
		ItemCarrinho item1 = new ItemCarrinho(pepsi, 3);
		ItemCarrinho item2 = new ItemCarrinho(camiseta, 2);
		ItemCarrinho item3 = new ItemCarrinho(pizza, 3);

		Carrinho carrinho = new Carrinho();
		carrinho.adicionaAoCarrinho(item1);
		carrinho.adicionaAoCarrinho(item2);
		carrinho.adicionaAoCarrinho(item3);

		// ordenamos o array por pre�o total de cada item decrescente
		List<ItemCarrinho> ordenarItensDecrescente = carrinho.ordenarItensDecrescente(carrinho.getItens());

		// pepsi 4 * 3 -> 12, camiseta 99.90 * 2 = 199.80, pizza 7.99 * 3 = 23.97
		// a ordena��o final deve ficar: [camiseta, pizza, pepsi] ent�o vamos ver se o primeiro item � a camiseta

		Produto produto = ordenarItensDecrescente.get(0).getProduto();
		assertThat(produto.getNome(), is("Polo Red Bull"));
	}

	// 3
	@Test
	public void deveOrdenarPeloPrecoCrescente() {
		ItemCarrinho item1 = new ItemCarrinho(pepsi, 3);
		ItemCarrinho item2 = new ItemCarrinho(camiseta, 2);
		ItemCarrinho item3 = new ItemCarrinho(pizza, 3);

		Carrinho carrinho = new Carrinho();
		carrinho.adicionaAoCarrinho(item1);
		carrinho.adicionaAoCarrinho(item2);
		carrinho.adicionaAoCarrinho(item3);

		// ordenamos o array por pre�o total de cada item decrescente
		List<ItemCarrinho> ordenarItensDecrescente = carrinho.ordenarItensCrescente(carrinho.getItens());

		// pepsi 4 * 3 -> 12, camiseta 99.90 * 2 = 199.80, pizza 7.99 * 3 = 23.97
		// a ordena��o final deve ficar: [pepsi, pizza, camiseta] ent�o vamos ver se o primeiro item � a pepsi

		Produto produto = ordenarItensDecrescente.get(0).getProduto();
		assertThat(produto.getNome(), is("Pepsi"));
	}

	// 4
	@Test
	public void deveTotalizarValorDoCarrinho() {
		ItemCarrinho item1 = new ItemCarrinho(pepsi, 3);
		ItemCarrinho item2 = new ItemCarrinho(camiseta, 2);
		ItemCarrinho item3 = new ItemCarrinho(pizza, 3);

		Carrinho carrinho = new Carrinho();
		carrinho.adicionaAoCarrinho(item1);
		carrinho.adicionaAoCarrinho(item2);
		carrinho.adicionaAoCarrinho(item3);

		// pepsi = 9.5 * 3 = 28.50 (com desconto de 5%)
		// camiseta = 100 * 2 = 150 (com desconto de 25%)
		// pizza = 15 * 3 = 45 (sem desconto)
		// total 223.50

		assertThat(carrinho.getValorTotalCarrinho(), is(223.50));
	}

	// 5
	@Test
	public void deveDarDescontoDeBebida() {
		ItemCarrinho item1 = new ItemCarrinho(pepsi, 1);

		Carrinho carrinho = new Carrinho();
		carrinho.adicionaAoCarrinho(item1);

		// o pre�o da pepsi � 10.0 por�m com desconto fica 9.5
		assertThat(carrinho.getValorTotalCarrinho(), is(9.5));
	}

	// 5
	@Test
	public void deveDarDescontoDeVestuario() {
		ItemCarrinho item1 = new ItemCarrinho(camiseta, 1);

		Carrinho carrinho = new Carrinho();
		carrinho.adicionaAoCarrinho(item1);

		// o pre�o da camiseta � 100.0 por�m com desconto fica 75.0
		assertThat(carrinho.getValorTotalCarrinho(), is(75.0));
	}

}