package br.edu.unoesc.produto;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * 
 * @author grando
 *
 */
public class Vestuario extends Produto {

	/**
	 * Se o produto for do tipo Vestu�rio ele automaticamente tem um pre�o com 25% de desconto
	 */
	@Override
	public Double getPrecoComDesconto() {
		double precoFinal = getPreco() - (getPreco() * 0.25);

		BigDecimal bd = new BigDecimal(precoFinal).setScale(2, RoundingMode.HALF_EVEN);
		return bd.doubleValue();
	}

}