package br.edu.unoesc.produto;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * 
 * @author grando
 * 
 */
public class Bebida extends Produto {

	/**
	 * Se o produto for do tipo Bebida ele automaticamente tem um pre�o com 5% de desconto
	 */
	@Override
	public Double getPrecoComDesconto() {
		double precoFinal = getPreco() - (getPreco() * 0.05);

		BigDecimal bd = new BigDecimal(precoFinal).setScale(2, RoundingMode.HALF_EVEN);
		return bd.doubleValue();
	}

}