package br.edu.unoesc.produto;

/**
 * 
 * @author grando
 *
 */
public class Comida extends Produto {

	@Override
	public Double getPrecoComDesconto() {
		return getPreco();
	}

}