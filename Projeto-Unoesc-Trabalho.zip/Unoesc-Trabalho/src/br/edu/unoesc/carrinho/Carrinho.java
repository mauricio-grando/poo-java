package br.edu.unoesc.carrinho;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * 
 * @author grando
 * 
 */
public class Carrinho {

	private List<ItemCarrinho> itens;

	public List<ItemCarrinho> getItens() {
		return itens;
	}

	public void setItens(List<ItemCarrinho> itens) {
		this.itens = itens;
	}

	/**
	 * Ordena os itens de forma crescente
	 * 
	 * @param itens
	 * @return
	 */
	public List<ItemCarrinho> ordenarItensCrescente(List<ItemCarrinho> itens) {
		Collections.sort(itens, new Comparator<ItemCarrinho>() {
			public int compare(ItemCarrinho item1, ItemCarrinho item2) {
				Double preco1 = item1.getValorTotalItem();
				Double preco2 = item2.getValorTotalItem();

				return preco1.compareTo(preco2);
			}
		});

		return itens;
	}

	/**
	 * Ordena os itens de forma decrescente
	 * 
	 * @param itens
	 * @return
	 */
	public List<ItemCarrinho> ordenarItensDecrescente(List<ItemCarrinho> itens) {
		Collections.sort(itens, new Comparator<ItemCarrinho>() {
			public int compare(ItemCarrinho item1, ItemCarrinho item2) {
				Double preco1 = item1.getValorTotalItem();
				Double preco2 = item2.getValorTotalItem();

				return preco2.compareTo(preco1);
			}
		});

		return itens;
	}

	/**
	 * M�todo que itera nos itens e pega o preco total de cada um baseado na quantidade
	 * 
	 * @return
	 */
	public Double getValorTotalCarrinho() {
		Double total = 0.0;

		for (ItemCarrinho item : getItens()) {
			Double preco = item.getProduto().getPrecoComDesconto();
			total += preco * item.getQuantidade();
		}

		return total;
	}

	/**
	 * M�todo que adiciona um item ao carrinho, verificando se o list � nulo
	 * 
	 * @param item
	 */
	public void adicionaAoCarrinho(ItemCarrinho item) {
		if (itens == null) {
			itens = new ArrayList<ItemCarrinho>();
		}
		itens.add(item);
	}

}